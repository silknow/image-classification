SILKNOW Image Classification
===============================

version number: 0.0.1
author: Dominic Clermont

Overview
--------

Classifier for images of silk fabrics

Installation / Usage
--------------------

To install use pip:

    $ pip install SilknowClassification


Or clone the repo:

    $ git clone https://github.com/silknow/SilknowClassification.git
    $ python setup.py install
    
Contributing
------------

TBD

Example
-------

TBD