# -*- coding: utf-8 -*-
"""
"""
import os
import collections
import random
import numpy as np
import matplotlib.pyplot as plt
import itertools
import tensorflow as tf
import tensorflow_hub as hub
#import tensorflow_probability as tfp

from sklearn.metrics import confusion_matrix, f1_score
from sklearn.metrics import precision_score, recall_score, accuracy_score

# also needed (but not in a function) in train_ResNet_152_V2_MTL.py
def master_file_to_collections_list(master_dir, master_file_name):
    r"""Imports the collection names from the master file.
    
    :Arguments\::
        :master_dir (*string*)\::
            This variable is a string and contains the name of the master file.
            The master file has to contain a list of the "collection.txt".
            All "collection.txt" have to be in the same folder as the master
            file.
            In the "collection.txt" are relative paths to the images and the
            according class label listed. The paths in a "collection.txt" has to
            be "some_rel_path_from_location_of_master_txt/image_name.jpg".
            The "collection.txt" has to have a header "#image\t#Label" and the
            following lines "path_with_image\timage_label".
        :master_file_name (*string*)\::
            The name of the 
    
    :Returns\::
        :collections_list (*list*)\::
            Contains as entries the collection.txt as a string.
            Each array entry corresponds to one collection.
            In the collection.txt are relative paths to the images and the
            according class label listed. The paths in a collection.txt has to
            be "some_rel_path_from_location_of_master_txt/image_name.jpg'.
            The collection.txt has to have a header "#image\t#Label" and the
            following lines "path_with_image\timage_label".
    """
    # Get image_lists out of the Master.txt
    master_id = open(os.path.abspath(master_dir + '/' + master_file_name), 'r')
    collections_list = []
    for collection in master_id:
        collections_list.append(collection.strip())
    master_id.close()
#    print('Got the following collections:', collections_list, '\n')
    return collections_list


def get_image_paths_from_collection(master_dir, collections_file,
                                    num_input_images):
    r"""Imports the image paths from a collection.
    
    :Arguments\::
        :master_dir (*string*)\::
            This variable is a string and contains the name of the master file.
            The master file has to contain a list of the "collection.txt".
            All "collection.txt" have to be in the same folder as the master
            file.
            In the "collection.txt" are relative paths to the images and the
            according class label listed. The paths in a "collection.txt" has to
            be "some_rel_path_from_location_of_master_txt/image_name.jpg".
            The "collection.txt" has to have a header "#image\t#Label" and the
            following lines "path_with_image\timage_label".
        :collections_file (*string*)\::
            In the "collection.txt" are relative paths to the images and the
            according class label listed. The paths in a "collection.txt" has to
            be "some_rel_path_from_location_of_master_txt/image_name.jpg".
            The "collection.txt" has to have a header "#image\t#Label" and the
            following lines "path_with_image\timage_label".
        :num_input_images (*int*)\::
            The number of input images that shall be considered.
    
    :Returns\::
        :image_path_list (*list*)\::
            It's a list containing the absolute paths of the num_input_images
            images.
    """
    coll_id = open(os.path.join(master_dir, collections_file), 'r')
    image_path_list = []
    first_line_passed = False
    image_counter = 0
    for im_line in coll_id:
        if first_line_passed == False:
            first_line_passed = True
            continue
        if image_counter == num_input_images:
            break  
        image_path  = im_line.split('\t')[0]
        image_path_list.append(os.path.join(master_dir, image_path))
        image_counter = image_counter + 1
    
    coll_id.close()
    
    if image_counter < num_input_images:
        print('Desired number of images for that similar images',
              'shall be searched:', num_input_images)
        print('Number of provided images:', image_counter)
        print('Continuing with the given', image_counter, 'images')
    return image_path_list


# from: train_ResNet_152_V2_MTL.py
def collections_list_to_image_lists(collections_list, labels_2_learn,
                                    min_samples_per_class, master_dir,
                                    bool_CrossVal):
    r"""Creates image_lists.
    
    :Arguments\::
        :collections_list (*list*)\::
            Is an array. Contains as entries the collection.txt as a string.
            Each array entry corresponds to one collection.
            In the collection.txt are relative paths to the images and the
            according class label listed. The paths in a collection.txt has to
            be "some_rel_path_from_location_of_master_txt/image_name.jpg'.
            The collection.txt has to have a header "#image\t#Label" and the
            following lines "path_with_image\timage_label".
        :labels_2_learn (*list*)\::
            The name of the '#label' that shall be learnt. It is of special
            interest if more than one label is given per image in the
            collections.txt.
        :min_samples_per_class (*int*)\::
            An integer that specifies the minimum number of samples per class
            that are desired. If the number of samples is less, the class
            won't be considered in learning and the samples are rejected from
            learning without data gaps.
        :master_dir (*string*)\::
            This variable is a string and contains the name of the master file.
            The master file has to contain a list of the "collection.txt".
            All "collection.txt" have to be in the same folder as the master
            file.
            In the "collection.txt" are relative paths to the images and the
            according class label listed. The paths in a "collection.txt" has to
            be "some_rel_path_from_location_of_master_txt/image_name.jpg".
            The "collection.txt" has to have a header "#image\t#Label" and the
            following lines "path_with_image\timage_label".
            
    :Returns\::
        :collections_dict (*dictionary*)\::
            It's a dict, that has the class labels as keys and the according
            paths (relative to the master_file.txt) including the image names
            as values.
        :label_2_image (*dictionary*)\::
            It's a dict, that has the class labels as keys and the according
            image names as values.
            (Not corrected if class contains too less images!!!)
    
    """
    # Teste, dass gleiche labels in allen collections.txt
    collections_dict = {}
    label_2_image    = {}
    for collection in collections_list:
        coll_id = open(os.path.join(master_dir, collection), 'r', encoding='utf8', errors='ignore')
        first_line_passed = False
        for im_line in coll_id:
            if first_line_passed == False:
                ind_label_2_extract = im_line.strip().replace(' ', '')\
                                    .replace('\t', '').split('#')[1:]\
                                    .index(labels_2_learn[0])
#                label = im_line.strip().replace(' ', '')\
#                                    .replace('\t', '')\
#                                    .split('#')[1:][ind_label_2_extract]
#                print('The following label will be extracted for all images:',
#                      label,
#                      '\n')
                first_line_passed = True
                continue
            
            image_path  = im_line.split('\t')[0]
            class_label = im_line.split('\t')[ind_label_2_extract].replace('\n', '')

            image_name  = image_path.split('/')[-1]
            
            if class_label not in collections_dict.keys():
                collections_dict[class_label] = [image_path]
            else:
                collections_dict[class_label].append(image_path)
                
            if class_label not in label_2_image.keys():
                label_2_image[class_label] = [image_name]
            else:
                label_2_image[class_label].append(image_name)
        coll_id.close()
                
#    # The following lines were relevant for references that did not consider
#    # min_samples_per_class
#    classes_2_delete = []
#    for c_label in collections_dict.keys():
#        if len(collections_dict[c_label]) < min_samples_per_class:
#            classes_2_delete.append(c_label)
#    for c_2_del in classes_2_delete:
#        del collections_dict[c_2_del]
#        print('The label', c_2_del, 'has less than', min_samples_per_class,
#              'samples in the class', c_2_del,
#              'and is therefore excluded from training!\n',
#              'Increase "min_samples_per_class" in the control file to consider that class.\n\n')
    
#    if not bool_CrossVal:
    if 'NaN' in collections_dict.keys():
        del collections_dict['NaN']
            
    collections_dict = collections.OrderedDict(sorted(collections_dict.items()))
#    print('The following classes will be learnt for the label',
#          label, ':', collections_dict.keys(), '\n')            
    
    return (collections_dict, label_2_image)


# from: train_ResNet_152_V2_MTL.py
def collections_list_MTL_to_image_lists(collections_list, labels_2_learn,
                                        min_samples_per_class, master_dir,
                                        bool_CrossVal):
    r"""Creates image_lists.
    
    :Arguments\::
        :collections_list (*list*)\::
            Is an array. Contains as entries the collection.txt as a string.
            Each array entry corresponds to one collection.
            In the collection.txt are relative paths to the images and the
            according class label listed. The paths in a collection.txt has to
            be "some_rel_path_from_location_of_master_txt/image_name.jpg'.
            The collection.txt has to have a Header "#image\t#Label" and the
            following lines "path_with_image\timage_label".
        :labels_2_learn (*list*)\::
            The name of the '#label' that shall be learnt. It is of special
            interest if more than one label is given per image in the
            collections.txt.
        :min_samples_per_class (*int*)\::
            An integer that specifies the minimum number of samples per class
            that are desired. If the number of samples is less, the class
            won't be considered in learning and the samples are rejected from
            learning without data gaps.
        :master_dir (*string*)\::
            This variable is a string and contains the name of the master file.
            The master file has to contain a list of the "collection.txt".
            All "collection.txt" have to be in the same folder as the master
            file.
            In the "collection.txt" are relative paths to the images and the
            according class label listed. The paths in a "collection.txt" has to
            be "some_rel_path_from_location_of_master_txt/image_name.jpg".
            The "collection.txt" has to have a header "#image\t#Label" and the
            following lines "path_with_image\timage_label".
            
    
    :Returns\::
        :collections_dict_MTL (*dictionary*)\::
            It's a dict containing the different image labels as keys and the
            according "collections_dict" as value.
            
            collections_dict_MTL[#label][class label][images]
        :image_2_label_dict (*dictionary*)\::
            A dictionary with the image (base) name as key and a list of avaiable
            #labels as value. It's needed for the estimation of the multitask
            loss.
            
            image_2_label_dict[full_image_name][#label_1, ..., #label_N]
    """
    collections_dict_MTL = {}
    image_2_label_dict   = {}
    label_2_image_dict   = {}
    for im_label in labels_2_learn:
        temp_label_dict, temp_im2label_dict = collections_list_to_image_lists(
                                                            collections_list,
                                                            [im_label],
                                                            min_samples_per_class,
                                                            master_dir,
                                                            bool_CrossVal)
        collections_dict_MTL[im_label] = temp_label_dict
        label_2_image_dict = {**label_2_image_dict, **temp_im2label_dict}
    
    for im_label in collections_dict_MTL.keys():
        for class_label in collections_dict_MTL[im_label]:
            for image in collections_dict_MTL[im_label][class_label]:
                if image not in image_2_label_dict.keys():
                    temp_label_dict = {}
                    temp_label_dict[im_label] = [class_label]
                    for im_label_2 in collections_dict_MTL.keys():
                        for class_label_2 in collections_dict_MTL[im_label_2]:
                            if image in collections_dict_MTL[im_label_2][class_label_2]:
                                temp_label_dict[im_label_2] = [class_label_2]
                    full_image_name = os.path.abspath(
                                        os.path.join(master_dir, image))
                    image_2_label_dict[full_image_name] = temp_label_dict
                
    return collections_dict_MTL, image_2_label_dict


# imported from: http://scikit-learn.org/stable/auto_examples/model_selection/plot_confusion_matrix.html#sphx-glr-auto-examples-model-selection-plot-confusion-matrix-py
def plot_confusion_matrix(cm, classes,
                          normalize=False,
                          title='Confusion matrix',
                          cmap=plt.cm.Blues):
    r"""
    This function prints and plots the confusion matrix.
    Normalization can be applied by setting `normalize=True`.
    """
    if normalize:
        cm = cm.astype('float') / cm.sum(axis=1)[:, np.newaxis]
        print("Normalized confusion matrix")
    else:
        print('Confusion matrix, without normalization')

    print(cm)
    
#    plt.rcParams["figure.figsize"] = [8, 8]
    plt.imshow(cm, interpolation='nearest', cmap=cmap)
    plt.title(title)
    plt.colorbar()
    tick_marks = np.arange(len(classes))
    plt.xticks(tick_marks, classes, rotation=0)
    plt.yticks(tick_marks, classes)

    fmt = '.2f' if normalize else 'd'
    thresh = cm.max() / 2.
    for i, j in itertools.product(range(cm.shape[0]), range(cm.shape[1])):
        plt.text(j, i, format(cm[i, j], fmt),
                 horizontalalignment="center",
                 color="white" if cm[i, j] > thresh else "black")

    plt.tight_layout()
    plt.ylabel('True label')
    plt.xlabel('Predicted label')
    

# from: train_ResNet_152_V2_MTL.py
def estimate_quality_measures(ground_truth, prediction, list_class_names,
                              prefix_plot, res_folder_name,
                              how_many_training_steps, bool_MTL):
    r"""
    """
    if not os.path.exists(res_folder_name):
        os.makedirs(res_folder_name)
        
    # Confusin Matrix (unnormalized)
    #print("ground_truth:",np.asarray(ground_truth))
    #print("prediction:",np.asarray(prediction))
    conf_mat = confusion_matrix(np.asarray(ground_truth), 
                                np.asarray(prediction))
    fig_conf_mat = plt.figure()
    plot_confusion_matrix(conf_mat, 
                          classes=list_class_names,
                          title='Confusion matrix')
#    plt.show()
    fig_conf_mat.savefig(res_folder_name + '/' + prefix_plot +
                         'Confusion_Matrix.jpg')
  
    # Confusin Matrix (normalized)
    conf_mat = confusion_matrix(np.asarray(ground_truth), 
                                np.asarray(prediction))
    fig_conf_mat_norm = plt.figure()
    plot_confusion_matrix(conf_mat, 
                          classes=list_class_names, 
                          normalize=True,
                          title='Normalized confusion matrix')
#    plt.show()
    fig_conf_mat_norm.savefig(res_folder_name + '/' + prefix_plot +
                              'Confusion_Matrix_normalized.jpg')
    
    # f1-scores
    f1_None     = f1_score(np.asarray(ground_truth), 
                         np.asarray(prediction), 
                         average=None)  
    
    # Precision
    precision_None     = precision_score(np.asarray(ground_truth), 
                                       np.asarray(prediction), 
                                       average=None)
  
    # Recall
    recall_None     = recall_score(np.asarray(ground_truth), 
                                       np.asarray(prediction), 
                                       average=None)
    
    # Write results to file
    data_amount = len(ground_truth) 
    overall_accuracy = accuracy_score(np.asarray(ground_truth), 
                                       np.asarray(prediction))
    text_file_result = open(res_folder_name + '/' + prefix_plot +
                            "Classification_results.txt", "w")  
    text_file_result.write("Number of Iterations: " + 
                           str(how_many_training_steps) + "\n")
    text_file_result.write("Total amount of data (" + prefix_plot + "): " + 
                           str(data_amount) + " images \n \n")  
    text_file_result.write("Overall Accuracy: %.2f %% \n \n" % 
                         (overall_accuracy*100))
    text_file_result.write("Class       \t Precision   \t Recall  \t f1-score \tContribution\n")
    text_file_result.write("            \t [%]         \t [%]     \t [%]      \n")
    for classes_index, class_name in enumerate(list_class_names):    
        if bool_MTL:
            text_file_result.write("%s \t\t %.2f        \t %.2f    \t %.2f   \t %d \n" %
                         (class_name,
                          precision_None[classes_index]*100,
                          recall_None[classes_index]*100,
                          f1_None[classes_index]*100,
                          (ground_truth == classes_index).sum()))
        else:
            if not isinstance(ground_truth, np.ndarray):
                text_file_result.write("%s \t\t %.2f        \t %.2f    \t %.2f   \t %d \n" %
                         (class_name,
                          precision_None[classes_index]*100,
                          recall_None[classes_index]*100,
                          f1_None[classes_index]*100,
                          ground_truth.count(classes_index)))
            else:
                text_file_result.write("%s \t\t %.2f        \t %.2f    \t %.2f   \t %d \n" %
                         (class_name,
                          precision_None[classes_index]*100,
                          recall_None[classes_index]*100,
                          f1_None[classes_index]*100,
                          (ground_truth == classes_index).sum()))
    text_file_result.write("Average     \t %.2f        \t %.2f    \t %.2f \n" %
                         (np.mean(precision_None)*100, np.mean(recall_None)*100,
                          np.mean(f1_None)*100))
  
    text_file_result.close()
    plt.close('all')
    

def get_statistic_dict(num_labels, coll_dict, relevant_labels):
    r"""Creates statistic_dict.
    
    :Arguments\::
        :num_labels (*int*)\::
            The number of labels/tasks/variables that shall have a class label
            for each image that shall be considered in statistic_dict.
        :coll_dict (*dictionary*)\::
            It's a dict, that has the class labels as keys and the according
            paths (relative to the master_file.txt) including the image names
            as values.
        :relevant_labels (*list*)\::
            A list of labels/variables/tasks that shall be considered in the
            creation of the statisitc dict.
            
    :Returns\::        
        :statistic_dict (*dictionary*)\::
            A dictionary having the relevant_labels as keys and lists of the
            according class labels of the found images with num_lables labels
            as values.
        :count_images (*int*)\::
            The number of images that were found with num_labels labels.
    
    """
    count_images = 0
    statistic_dict = {}
    for image in coll_dict.keys():
        label_count = 0
        for variable in coll_dict[image].keys():
            if variable in relevant_labels\
            and coll_dict[image][variable] != 'NaN':
                label_count = label_count + 1
        if label_count == num_labels:
            count_images = count_images + 1
            for variable in coll_dict[image].keys():
                if variable not in statistic_dict.keys():
                    statistic_dict[variable] = [coll_dict[image][variable][0]]
                else:
                    statistic_dict[variable].append(coll_dict[image][variable][0])
    
    return statistic_dict, count_images


def make_label_statistics(class_label_list, output_path, output_file,
                          label):
    full_fig_name = os.path.join(output_path, output_file + '.jpg')
    full_txt_name = os.path.join(output_path, output_file + '.txt')
    classes = list(set(class_label_list))
    counts  = []
    
    txt_id = open(full_txt_name, 'w')
    for temp_class in classes:
        temp_count = class_label_list.count(temp_class)
        counts.append(temp_count)
        txt_id.write(str(temp_count) + \
                     '\t' + temp_class + '\n')
    txt_id.close()
    
    fig_id    = plt.figure()
    x_entries = np.arange(len(classes))
    plt.bar(x_entries, counts)
    plt.xticks(x_entries, classes, rotation=-45)
    plt.ylabel('number of samples')
    plt.title('Distribution of class labels\n(' + label +')')
    plt.show()
    fig_id.savefig(full_fig_name) 
    
# adapted from: http://scikit-learn.org/stable/auto_examples/model_selection/plot_confusion_matrix.html#sphx-glr-auto-examples-model-selection-plot-confusion-matrix-py
def plot_cooccurence_matrix(cm, classes,
                          title,
                          cmap=plt.cm.Blues,
                          result_folder=None,
                          figsize=(15, 15),
                          dpi=80,
                          fontsize=20):
    r"""
    This function plots the cooccurence matrix.
    """
    
#    plt.rcParams["figure.figsize"] = [8, 8]
    fig_id = plt.figure(num=None, figsize=figsize, dpi=dpi, facecolor='w', edgecolor='k')
    plt.rcParams.update({'font.size': fontsize})
    plt.imshow(cm, interpolation='nearest', cmap=cmap)
    plt.title(title)
    plt.colorbar()
    tick_marks = np.arange(len(classes))
    plt.xticks(tick_marks, classes, rotation='vertical')
    plt.yticks(tick_marks, classes)

    fmt = 'd'
    thresh = cm.max() / 2.
    for i, j in itertools.product(range(cm.shape[0]), range(cm.shape[1])):
        plt.text(j, i, format(cm[i, j], fmt),
                 horizontalalignment="center",
                 color="white" if cm[i, j] > thresh else "black")

    plt.tight_layout()
    plt.margins(5)
    plt.subplots_adjust(bottom=0.15)
    
    if result_folder is not None:
        fig_id.savefig(os.path.join(result_folder, title + '.jpg')) 
    
def get_cooccurence_statistic(statistic_dict, coll_dict, result_folder=None):
    r"""Plots one cooccurence matrix for each possible level of incompleteness.
    
    :Arguments\::
        :statistic_dict (*dictionary*)\::
            A dictionary having the relevant_labels as keys and lists of the
            according class labels of the found images with num_lables labels
            as values. (i.e. the first output from get_statistic_dict)
        :coll_dict (*dictionary*)\::
            A dictionary with the image (base) name as key and a list of avaiable
            #labels as value. (i.e. the second output from collections_list_MTL_to_image_lists)
        :result_folder (*string*)\::
            Relative path to the folder where the plots are saved. 
            The plots will not be saved if this variable is not passed to the function.
            
    :Returns\::     
    """
    
    # Get names of all occuring class names of all variables
    class_list = []
    for i in range(len(statistic_dict.keys())):
        class_list += list(np.unique(np.asarray(list(statistic_dict.values()))[i]))
    
    # create empty cooccurence matrices
    num_labels = len(statistic_dict.keys())
    coocmat = np.zeros((len(class_list),len(class_list), num_labels), dtype=np.int32)
    
    # fill matrices according to level of incompleteness
    for image in coll_dict.keys():
        image_class_list = np.asarray(list(coll_dict[image].values())).flatten()
        indices = [class_list.index(image_class_list[i]) for i in range(len(image_class_list))]
        for ind1 in indices:
            for ind2 in indices:
                coocmat[ind1, ind2, len(image_class_list)-1] += 1
    # print matrices according to level of incompleteness            
    for incomp_level in range(num_labels):
        plot_cooccurence_matrix(coocmat[:,:,incomp_level], class_list, 
                                title='Cooccurence matrix - '+str(int(incomp_level+1))+' variable(s)', 
                                result_folder=result_folder)
        
    # print cooccurences independent of incompleteness
    plot_cooccurence_matrix(np.sum(coocmat, axis=-1), class_list, 
                            title='Cooccurence matrix - ignoring level of incompleteness', 
                            result_folder=result_folder)    


def add_data_augmentation(flip_left_right = None, flip_up_down = None, random_shear = None,
                          random_brightness = None, random_crop = None, random_rotation = None,
                          random_contrast = None, random_hue = None, random_saturation = None,
                          random_rotation90 = None, input_im_tensor = None):
    r"""Realizes data augmentation.
    
    :Arguments\::
        :flip_left_right (*bool*)\::
            Whether to randomly mirrow the image horizontally along its
            vertical centre line.
        :flip_up_down (*bool*)\::
            Whether to randomly mirrow the image vertically along its
            horizontal centre line.
        :random_shear (*list*)\::
            The list contains float value ranges from which the parameters for
            shearing horizontally (hor) and vertically (vert) will be drawn:
                [lower bound hor, upper boudn hor, lower bound vert,
                upper bound vert]
        :random_brightness (*float*)\::
            Multiplies all image channels independently of all pixels by a
            random value out of the range
            [1 - random_brightness/100; 1 + random_brightness/100].
        :random_crop (*list*)\::
            Range of float fractions for centrally cropping the image. The crop fraction
            is drawn out of the provided range [lower bound, upper bound], 
            i.e. the first and second values of random_crop.
        :random_rotation (*float*)\::
            Randomly rotates the image counter clockwise by a random angle in
            the range [-random_rotation; +random_rotation]. The angle has to be
            given in radians.
        :random_contrast (*list*)\::
           Adjusts the contrast of an image or images by a random factor. 
           random_contrast has to be an array with 2 values. The first value
           is the lower bound for the random factor, the second value is the
           upper bound for the random factor.
        :random_hue (*float*)\::
           Adjusts the hue of RGB images by a random factor. random_hue has to
           be between 0 and 0.5. The hue will be adjusted by a random factor
           picked from the interval [-random_hue, random_hue]
        :random_saturation (*list*)\::
           Adjusts the saturation of an image or images by a random factor. 
           random_saturation has to be an array with 2 values. The first value
           is the lower bound for the random factor, the second value is the
           upper bound for the random factor.
        :random_rotation90 (*bool*)\::
            If True, the image will be rotated counter-clockwise by 90 degrees
            (with a chance of 50%).
        :input_im_tensor (*tensor*)\::
            The input image that will be transformed. Must be a tensor of rank 3,
            with sizes [image_height, image_width, image_channels]
    
    :Returns\::
        : tranformed_image (*tensor*)\::
            The output image after applying the transformations. Is the same type
            as input_im_tensor.
    
    """
    assert input_im_tensor is not None, "No image was provided to the data augmentation!"
    tranformed_image = input_im_tensor
    
    if random_rotation is not None:
        # added: random_rotation
        rotation_min  = -random_rotation
        rotation_max =  random_rotation
        rotation_value = tf.random_uniform(shape=[],
                                           minval=rotation_min,
                                           maxval=rotation_max)
        tranformed_image  = tf.contrib.image.rotate(tranformed_image,
                                                 rotation_value)
    if random_rotation90 is not None:
        # added: randomly rot90
        if random_rotation90:
            rot90_indicator = tf.random_uniform(shape=[], minval=0, maxval=1)
            test_rot90 = tf.constant(0.5, dtype = tf.float32)
            tranformed_image = tf.cond(rot90_indicator >= test_rot90,
                                    lambda: tf.image.rot90(tranformed_image, k = 1),
                                    lambda: tf.image.rot90(tranformed_image, k = 0))
        else:
            tranformed_image = tranformed_image
    
    if flip_left_right is not None:
        if flip_left_right:
            tranformed_image = tf.image.random_flip_left_right(tranformed_image)

    if flip_up_down is not None:
        # added: random_flip_up_down
        if flip_up_down:
            tranformed_image = tf.image.random_flip_up_down(tranformed_image)
  
    if random_brightness is not None:
        # brightness
        brightness_min   = 1.0 - (random_brightness / 100.0)
        brightness_max   = 1.0 + (random_brightness / 100.0)
        brightness_value = tf.random_uniform(shape=[],
                                       minval=brightness_min,
                                       maxval=brightness_max)
        tranformed_image = tf.multiply(tranformed_image, brightness_value)
  
    if random_contrast is not None:
        # added: random_contrast
        # contrast_min >= 0, contrast_min < contrast_max!
        assert random_contrast[0] >= 0, "Minimum Contrast has to be larger than 0!"
        assert random_contrast[1] > random_contrast[0], "Maximum Contrast has to be smaller than Minimum Contrast!"
        contrast_min      = random_contrast[0]
        contrast_max      = random_contrast[1]
        tranformed_image  = tf.image.random_contrast(tranformed_image,
                                               contrast_min,
                                               contrast_max)  
    if random_hue is not None:
        # added: random_hue
        # random_hue in [0, 0.5]!
        hue_value  = random_hue
        tranformed_image = tf.image.random_hue(tranformed_image, hue_value)
    
    if random_saturation is not None:
        # added: random_saturation
        # saturation_min >= 0, saturation_min < saturation_max!
        assert random_saturation[0] >= 0, "Minimum Saturation has to be larger than 0!"
        assert random_saturation[1] > random_saturation[0], "Maximum Saturation has to be smaller than Minimum Saturation!"
        saturation_min   = random_saturation[0]
        saturation_max   = random_saturation[1]
        tranformed_image  = tf.image.random_saturation(tranformed_image,
                                                saturation_min,
                                                saturation_max)  
    if random_shear is not None:
        # added: random_shear
        shear_w = tf.random_uniform(shape=[],
                                    minval = random_shear[0],
                                    maxval = random_shear[1])
        shear_h = tf.random_uniform(shape=[],
                                    minval = random_shear[2],
                                    maxval = random_shear[3])
        trafo_matrix = [1, shear_w, 0,
                        shear_h, 1, 0,
                        0, 0]
        tranformed_image = tf.contrib.image.transform(tranformed_image,
                                             trafo_matrix)
        
    if random_crop is not None:
        # added: random_crop
        crop_fraction = random.uniform(random_crop[0], random_crop[1])
        tranformed_image = tf.image.central_crop(tranformed_image, crop_fraction)

    return tranformed_image


   
def add_jpeg_decoding(input_height, input_width, input_depth, module_spec,
                      bool_hub_module,
                      bool_data_aug, aug_set_dict, crop_aspect_ratio=1):
    r"""Adds operations that perform JPEG decoding and resizing to the graph.
    
    :Arguments\::
        :input_height (*int*)\::
            Height of the input image. Can be ignored if a hub module is used.
        :input_width (*int*)\::
            Width of the input image. Can be ignored if a hub module is used.
        :input_depth (*int*)\::
            Channels of the input image. Can be ignored if a hub module is used.
        :module_spec (*module*)\::
            The hub.ModuleSpec for the image module being used.
        :bool_hub_module (*bool*)\::
            If True, a tensorflow hub module has to be chosen for the feature
            extraction by setting a valid URL for *tfhub_module*.
            If False, the currently implemented model in *setup_siamese_CNN()*
            will be fully trained to obtain a descriptor per image. As the
            model is fully convolutional, the user has to define an input size
            via setting *input_height*, *input_width* and *input_depth*.
        :bool_data_aug (*bool*)\::
            If True, data augmentation will be applied.
        :aug_set_dict (*dictionary*)\::
            The keys of aug_set_dict are the transformations that will be applied
            during data augmentation, the values are the corresponding transformation
            parameters. Detailed information about names and parameters of transformations
            are in the documentation of add_data_augmentation.
        :crop_aspect_ratio (*float*)\::
            If greater than 1, images will be cropped to their central square when their aspect ratio is
            greater than crop_aspect_ratio. 
            For example, an image with a height of 200 and a width of 400 has an aspect ratio of 2.
            When crop_aspect_ratio is set to 1.5, the exemplary image will be cropped to the region
            hmin=0 hmax=200 wmin=100 wmax=300.

    :Returns\::
        :jpeg_data_tensor (*tensor*)\::
            Tensor to feed JPEG data into it.
        :resized_image_tensor (*tensor*)\::
            Tensor that contains the result of the preprocessing steps.
    """
    if bool_hub_module:
        input_height, input_width = hub.get_expected_image_size(module_spec)
        input_depth = hub.get_num_image_channels(module_spec)
        
    print('Input dimensions of the pre-trained network:\n',
        input_height, input_width, input_depth)
    
    jpeg_data_tensor = tf.placeholder(tf.string, name='DecodeJPGInput')
    decoded_image    = tf.image.decode_jpeg(jpeg_data_tensor,
                                         channels=input_depth)
    decoded_image_as_float = tf.image.convert_image_dtype(decoded_image,
                                                        tf.float32)
    decoded_height = tf.cast(tf.shape(decoded_image_as_float)[0], tf.float32)
    decoded_width  = tf.cast(tf.shape(decoded_image_as_float)[1], tf.float32)
    
    if bool_data_aug:
        if "flip_left_right" not in aug_set_dict.keys(): aug_set_dict["flip_left_right"] = None
        if "flip_up_down" not in aug_set_dict.keys(): aug_set_dict["flip_up_down"] = None
        if "random_shear" not in aug_set_dict.keys(): aug_set_dict["random_shear"] = None
        if "random_brightness" not in aug_set_dict.keys(): aug_set_dict["random_brightness"] = None
        if "random_crop" not in aug_set_dict.keys(): aug_set_dict["random_crop"] = None
        if "random_rotation" not in aug_set_dict.keys(): aug_set_dict["random_rotation"] = None
        if "random_contrast" not in aug_set_dict.keys(): aug_set_dict["random_contrast"] = None
        if "random_hue" not in aug_set_dict.keys(): aug_set_dict["random_hue"] = None
        if "random_saturation" not in aug_set_dict.keys(): aug_set_dict["random_saturation"] = None
        if "random_rotation90" not in aug_set_dict.keys(): aug_set_dict["random_rotation90"] = None
        decoded_image_as_float = add_data_augmentation(
                        flip_left_right=aug_set_dict["flip_left_right"],
                        flip_up_down=aug_set_dict["flip_up_down"],
                        random_shear=aug_set_dict["random_shear"],
                        random_brightness=aug_set_dict["random_brightness"],
                        random_crop=aug_set_dict["random_crop"],
                        random_rotation=aug_set_dict["random_rotation"],
                        random_contrast=aug_set_dict["random_contrast"],
                        random_hue=aug_set_dict["random_hue"],
                        random_saturation=aug_set_dict["random_saturation"],
                        random_rotation90=aug_set_dict["random_rotation90"],
                        input_im_tensor=decoded_image_as_float)
        
    # Gaussian filtering before downsizing, we assume that the target image size is square
    sigma      = tf.cast(tf.shape(decoded_image)[0]/input_height, tf.float32)
    kernelsize = tf.cast(tf.cast(sigma*6, tf.int32) + (1-(tf.cast(sigma*6,
                         tf.int32)%2)), tf.float32)
    distr      = tf.distributions.Normal(0.0, sigma)
    vals       = distr.prob(tf.range(start = -kernelsize,
                                     limit = kernelsize + 1,
                                     dtype = tf.float32))
    gauss_kernel_2d = tf.einsum('i,j->ij',
                              vals,
                              vals)
    gauss_kernel_2d = gauss_kernel_2d / tf.reduce_sum(gauss_kernel_2d)                           
    decoded_image_4d = tf.expand_dims(decoded_image_as_float, 0) 
    gauss_kernel     = tf.tile(gauss_kernel_2d[:, :, tf.newaxis, tf.newaxis],
                           [1, 1, 3, 1])
    pointwise_filter = tf.eye(3, batch_shape=[1, 1]) # does nothing
    bool_downsize    = tf.placeholder(tf.bool)
    bool_downsize    = tf.cond(input_height<tf.maximum(decoded_height, decoded_width),
                               lambda: True, lambda: False)
    decoded_image_4d = tf.cond(bool_downsize,
                               lambda: tf.nn.separable_conv2d(decoded_image_4d,
                                                          gauss_kernel,
                                                          pointwise_filter,
                                                          strides=[1, 1, 1, 1],
                                                          padding="SAME"),
                              lambda: decoded_image_4d)
                               
                                   
    # Crop images to their central square, if their aspect ratio is too large
    decoded_height = tf.cast(tf.shape(decoded_image_4d)[1], tf.float32)
    decoded_width  = tf.cast(tf.shape(decoded_image_4d)[2], tf.float32)
    aspect_ratio = tf.maximum(decoded_height/decoded_width,
                          decoded_width/decoded_height)
    bool_crop = tf.cond(aspect_ratio > crop_aspect_ratio, lambda: True, lambda: False)
    crop_size = tf.cast(tf.minimum(decoded_height, decoded_width), tf.float32)
    crop_offset_height = tf.cast(tf.floor(decoded_height/tf.constant(2.) - crop_size/tf.constant(2.)), tf.int32)
    crop_offset_width  = tf.cast(tf.floor(decoded_width/tf.constant(2.) - crop_size/tf.constant(2.)), tf.int32)
    cropped_image_4d = tf.image.crop_to_bounding_box(decoded_image_4d,
                                                      crop_offset_height,
                                                      crop_offset_width,
                                                      tf.cast(crop_size-1.,tf.int32),
                                                      tf.cast(crop_size-1.,tf.int32))
    decoded_image_4d = tf.cond(bool_crop,
                               lambda: cropped_image_4d,
                               lambda: decoded_image_4d)
    
                                     
    resize_shape         = tf.stack([input_height, input_width])
    resize_shape_as_int  = tf.cast(resize_shape, dtype=tf.int32)
    resized_image_tensor = tf.image.resize_bilinear(decoded_image_4d,
                                           resize_shape_as_int)
    resized_image_tensor = tf.squeeze(resized_image_tensor)
    
    return jpeg_data_tensor, resized_image_tensor